### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlexandrBorovkov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AlexandrBorovkov/python-project-49/actions)

<a href="https://codeclimate.com/github/AlexandrBorovkov/python-project-49/maintainability">
    <img src="https://api.codeclimate.com/v1/badges/26fa5b8507991f84546f/maintainability" />
</a>
